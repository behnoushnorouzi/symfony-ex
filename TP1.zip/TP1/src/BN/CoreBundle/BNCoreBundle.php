<?php

namespace BN\CoreBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BNCoreBundle extends Bundle
{
}
